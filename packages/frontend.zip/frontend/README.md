note because this is in a monorepo had to remove react, react-dom, and react-native-web deps and change metro.config.js a bit.
