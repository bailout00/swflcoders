// Since I'm using expo-router, this is enough.
require('expo-router/entry');
